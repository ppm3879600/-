package cooking;

import java.util.ArrayList;

public class FoodStore {
	
	String sName; // 가게 이름
	int price; //메뉴들 가격 총합
	String introduce; //가게 소개
	
	String StoreInfo; //가게 정보
	String review; //(평점+이름+한줄평) 가게 음식 평가
	ArrayList<Menu> menulist=new ArrayList<Menu>();// 메뉴의 이름과 가격정보 배열방
	
	public FoodStore(String sName, String introduce, ArrayList<Menu> menulist, String StoreInfo) {
		this.sName=sName;
		this.introduce=introduce;
		this.menulist=menulist;
		this.StoreInfo=StoreInfo;
	}
	
	public String getStoreInfo() {
		return StoreInfo;
	}

	public void setStoreInfo(String storeInfo) {
		StoreInfo = storeInfo;
	}

	public ArrayList<Menu> getMenulist() {
		return menulist;
	}

	public void setMenulist(ArrayList<Menu> menulist) {
		this.menulist = menulist;
	}
	
	public String getMenu(int num) {
		return menulist.get(num).getName();
	}
	
	public int getMenuPrice(int num) {
		return menulist.get(num).getPrice();
	}
	
	public ArrayList<Menu> getmenulist() {
		return menulist;
	}

	public void setmenulist(ArrayList<Menu> menulist) {
		this.menulist = menulist;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	int total; //평점 누적합		
	int personScore; //방금 등록한 평점
	String rev; //한줄 평 등록
	int personNum; //평점 등록한 사람 수
	String reviewName = ""; //평점 등록한 사람 이름
	
	public String getsName() {
		return sName;
	}
	public void setsName(String cName) {
		this.sName = cName;
	}
	public int getPrice() {
		return price;
	}
	
	public void setPrice() {
		for(int i=0; i<menulist.size();i++) {
		this.price +=menulist.get(i).price;
		}
	}
	
	
	public String getIntroduce() {
		return introduce;
	}

	public void setIntroduce(String introduce) {
		this.introduce = introduce;
	}

	public String getReview() {
		return review;
	}
	public void setReview(String review) {
		this.review = review;
	}
	
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getPersonScore() {
		return personScore;
	}
	public void setPersonScore(int personScore) {
		this.personScore = personScore;
	}
	public String getRev() {
		return rev;
	}
	public void setRev(String rev) {
		this.rev = rev;
	}
	public int getPersonNum() {
		return personNum;
	}
	public void setPersonNum(int personNum) {
		this.personNum = personNum;
	}
	public String getReviewName() {
		return reviewName;
	}
	public void setReviewName(String reviewName) {
		this.reviewName = reviewName;
	}
	
	public int gettotalprice() {
		int sum=0;
		for(int i=0; i<MyMenu.buylist.size(); i++) {
			sum += MyMenu.buylist.get(i).getPrice()*MyMenu.buylist.get(i).getCount();
		}return sum;
	}
	
}
