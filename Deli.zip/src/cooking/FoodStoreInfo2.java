package cooking;

import java.awt.event.FocusListener;
import java.util.ArrayList;


public class FoodStoreInfo2{

	private static ArrayList<FoodStore> list;
	MenuCollect menucollect = new MenuCollect();

	public FoodStoreInfo2() {
		if (list == null) {
			init();
		}
	}

	private void init() {
		list = new ArrayList<FoodStore>();

		// 가게1 정보
		list.add(new FoodStore("홍콩반점0410",
				"가게소개:\r\n" + "중국집 메뉴판에서 으레 느끼는 것이 휘황찬란하고 어려운 이름의 수많은 메뉴입니다.\r\n"
						+ "자주 먹지도 않는 메뉴를 과감히 삭제하고, 가장 대표적인 메뉴에 " + "역량을 집중하면 더욱 훌륭한 맛이 탄생하지 않을까요?\r\n"
						+ "홍콩반점0410은 이런 질문으로부터 출발,\r\n" + "오직 짬뽕만을 다루는 짬뽕 전문점으로 시작했습니다.",
						MenuCollect.getHonkong(), MenuCollect.StoreInformation));

		// 가게2 정보
		list.add(new FoodStore("땅스부대찌개",
				"가게소개:\r\n" + "땅스부대찌개는 이땅위의부대찌개라는 슬로건으로\r\n" + "부대찌개분야에서 최고의 맛을 자신하는 부대찌개포장전문점입니다.\r\n"
						+ "거품 뺀 가격으로 푸짐한 양과 높은 퀄리티의 맛\r\n" + "그리고 저렴한 금액으로 소비자의 관심과 사랑을 받고있는\r\n"
						+ "부대찌개 테이크아웃 전문점입니다.",
						MenuCollect.getBudae(), MenuCollect.StoreInformation));

		// 가게3 정보
		list.add(new FoodStore("교촌치킨",
				"가게소개:\r\n" + "향교가 있는 마을, 교촌(校村)\r\n" + "향교는 선조들이 배움의 즐거움을 탐구하던 곳으로 우리네 모든 마을에 자리한 배움터였습니다.\r\n"
						+ "그 말의 의미를 담아 대한민국 곳곳에서 치킨의 맛의 즐거움을 탐구하고자\r\n" + "1991년 구미에서 교촌이 탄생하였습니다.",
						MenuCollect.getChieken(),MenuCollect.StoreInformation));

		list.add(new FoodStore("아웃백스테이크하우스",
				"가게소개:\r\n" + "1997년, 한국에 첫 번째 아웃백이 소개된 해입니다.\r\n" + "아웃백 스테이크하우스는 캐주얼한 분위기에서\r\n"
						+ "질 좋은 스테이크를 제공하고자 했던 초심을 중요하게 생각합니다.\r\n" + "최고의 음식은 최상의 재료와 최선을 다하는 태도에 있습니다.",
						MenuCollect.getOutback(),MenuCollect.StoreInformation));

	}

	public FoodStore searchStore(String name) {
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).getsName().equals(name)) {
				return list.get(i);
			}
		}
		return null;
	}
	
	

}
