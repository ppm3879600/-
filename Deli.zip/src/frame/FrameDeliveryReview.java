package frame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.TextEvent;
import java.awt.event.TextListener;
import java.awt.event.WindowAdapter;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;



public class FrameDeliveryReview extends JPanel {

   public FrameDeliveryReview() {

	// JPanel 기본 구조
      setBackground(new Color(255,255,255));
      setLayout(null);
      setSize(600, 800);

      //이미지
      ImageIcon pop = new ImageIcon("ㅇㅇㅇ.jpg");
      JLabel lbl = new JLabel(pop);
      lbl.setSize(600, 150);
      lbl.setLocation(-5, 0);
      add(lbl);
      
      //음식점 선택 창
      JPanel dis2 = new JPanel();
      dis2.setLayout(new GridLayout(1,3));
      dis2.setBounds(10, 150, 565, 60);
      dis2.setBackground(new Color(255,255,255));
      dis2.setBorder(new TitledBorder(new LineBorder(Color.LIGHT_GRAY), "음식점 선택", TitledBorder.LEFT, TitledBorder.TOP, 
    		  new Font (" monospaced", Font.BOLD, 17), new Color(255, 153, 051)));
      
     
      String mName[] = { "홍콩반점0410", "땅스부대찌개", "아웃백하우스", "교촌치킨" };
      ButtonGroup group1 = new ButtonGroup();
      JRadioButton menuButton[] = new JRadioButton[4];

      for (int i = 0; i < mName.length; i++) {
         menuButton[i] = new JRadioButton(mName[i]);
         menuButton[i].setFont(new Font("monospaced", Font.BOLD, 14));
         menuButton[i].setBackground(new Color(255,255,255));
         dis2.add(menuButton[i]);
         group1.add(menuButton[i]);

      } 
      
      add(dis2);
      //메뉴 선택 창
      JPanel lb1 = new JPanel();
      lb1.setLayout(new GridLayout(2,2));
      lb1.setBounds(10, 210, 565, 80);
      lb1.setBackground(new Color(255,255,255));

      lb1.setBorder(new TitledBorder(new LineBorder(Color.LIGHT_GRAY), "메뉴 선택", TitledBorder.LEFT, TitledBorder.TOP, 
    		  new Font (" monospaced", Font.BOLD, 17), new Color(255, 153, 051)));
      
 
      JRadioButton menuButton2[] = new JRadioButton[4];
      for (int i = 0; i < menuButton2.length; i++) {
    	  menuButton2[i] = new JRadioButton();
    	  menuButton2[i].setFont(new Font("monospaced", Font.BOLD, 14));
    	  menuButton2[i].setBackground(new Color(255,255,255));
	lb1.add(menuButton2[i]);
	menuButton2[i].setVisible(false);
      }
  add(lb1);
      
      menuButton[0].addActionListener(new ActionListener() {
  		
  		@Override
  		public void actionPerformed(ActionEvent e) {
  			
  			
  			menuButton2[0].setText("짬뽕");
  			menuButton2[1].setText("짜장면");
  			menuButton2[2].setText("고추짬뽕밥");
  			menuButton2[3].setText("탕수육");
  			
  			
  			menuButton2[0].setVisible(true);
  			menuButton2[1].setVisible(true);
  			menuButton2[2].setVisible(true);
  			menuButton2[3].setVisible(true);
	
  				}
  				
  			});
  

        menuButton[1].addActionListener(new ActionListener() {
    		
    		@Override
    		public void actionPerformed(ActionEvent e) {
    			
    			
    			menuButton2[0].setText("오리지널 부대찌개");
    			menuButton2[1].setText("치즈 부대찌개");
    			menuButton2[2].setText("베이컨 부대찌개");
    			menuButton2[3].setText("왕만두 부대찌개");
    			
    			
    			menuButton2[0].setVisible(true);
    			menuButton2[1].setVisible(true);
    			menuButton2[2].setVisible(true);
    			menuButton2[3].setVisible(true);
 			
    				}
    				
    			});
        
      
        menuButton[2].addActionListener(new ActionListener() {
    		
    		@Override
    		public void actionPerformed(ActionEvent e) {
    			
    			
    			menuButton2[0].setText("투움바파스타");
    			menuButton2[1].setText("아웃백 스페셜 갈릭 스테이크");
    			menuButton2[2].setText("베이비 백립");
    			menuButton2[3].setText("오지치즈 후라이즈");
    			
    			
    			menuButton2[0].setVisible(true);
    			menuButton2[1].setVisible(true);
    			menuButton2[2].setVisible(true);
    			menuButton2[3].setVisible(true);

    				}
    				
    			});
        
        menuButton[3].addActionListener(new ActionListener() {
    		
    		@Override
    		public void actionPerformed(ActionEvent e) {
    			
    			
    			menuButton2[0].setText("교촌리얼후라이드");
    			menuButton2[1].setText("교촌반반오리지날");
    			menuButton2[2].setText("교촌레드콤보");
    			menuButton2[3].setText("교촌허니콤보");
    			
    			
    			menuButton2[0].setVisible(true);
    			menuButton2[1].setVisible(true);
    			menuButton2[2].setVisible(true);
    			menuButton2[3].setVisible(true);
		
    				}
    				
    			});
        
        add(dis2);
      //평점 창 
      JPanel dis1 = new JPanel(); 
      dis1.setBackground(new Color(255,255,255));
      dis1.setSize(565, 170);
      dis1.setLocation(10, 290);
      dis1.setLayout(new GridLayout(0,6));
      dis1.setBorder(new TitledBorder(new LineBorder(Color.LIGHT_GRAY),
            "평점", TitledBorder.LEADING, 
            TitledBorder.TOP,
            new Font (" monospaced", Font.BOLD, 17), 
            new Color(255, 153, 051)));
      
      dis1.add(new JLabel("맛"));
      JRadioButton point1 = new JRadioButton("1점");
      point1.setBackground(new Color(255,255,255));
      JRadioButton point2 = new JRadioButton("2점");
      point2.setBackground(new Color(255,255,255));
      JRadioButton point3 = new JRadioButton("3점");
      point3.setBackground(new Color(255,255,255));
      JRadioButton point4 = new JRadioButton("4점");
      point4.setBackground(new Color(255,255,255));
      JRadioButton point5 = new JRadioButton("5점");
      point5.setBackground(new Color(255,255,255));
      point1.getText();
    
      dis1.add(point1);
      dis1.add(point2);
      dis1.add(point3);
      dis1.add(point4);
      dis1.add(point5);

      dis1.add(new JLabel("양 "));
      JRadioButton pt1 = new JRadioButton("1점");
      pt1.setBackground(new Color(255,255,255));
      JRadioButton pt2 = new JRadioButton("2점");
      pt2.setBackground(new Color(255,255,255));
      JRadioButton pt3 = new JRadioButton("3점");
      pt3.setBackground(new Color(255,255,255));
      JRadioButton pt4 = new JRadioButton("4점");
      pt4.setBackground(new Color(255,255,255));
      JRadioButton pt5 = new JRadioButton("5점");
      pt5.setBackground(new Color(255,255,255));

      dis1.add(pt1);
      dis1.add(pt2);
      dis1.add(pt3);
      dis1.add(pt4);
      dis1.add(pt5);

      dis1.add(new JLabel("배달 속도"));
      JRadioButton p1 = new JRadioButton("1점");
      p1.setBackground(new Color(255,255,255));
      JRadioButton p2 = new JRadioButton("2점");
      p2.setBackground(new Color(255,255,255));
      JRadioButton p3 = new JRadioButton("3점");
      p3.setBackground(new Color(255,255,255));
      JRadioButton p4 = new JRadioButton("4점");
      p4.setBackground(new Color(255,255,255));
      JRadioButton p5 = new JRadioButton("5점");
      p5.setBackground(new Color(255,255,255));


      dis1.add(p1);
      dis1.add(p2);
      dis1.add(p3);
      dis1.add(p4);
      dis1.add(p5);

      ButtonGroup group2 = new ButtonGroup();
      group2.add(point1);
      group2.add(point2);
      group2.add(point3);
      group2.add(point4);
      group2.add(point5);

      ButtonGroup group3 = new ButtonGroup();
      group3.add(pt1);
      group3.add(pt2);
      group3.add(pt3);
      group3.add(pt4);
      group3.add(pt5);

      ButtonGroup group4 = new ButtonGroup();
      group4.add(p1);
      group4.add(p2);
      group4.add(p3);
      group4.add(p4);
      group4.add(p5);
      add(dis1);
 
//----------------------------------------------------------------------
      
     /* JButton btn = new JButton("완료");
      
      btn.addActionListener(new ActionListener() {

         @Override
         public void actionPerformed(ActionEvent e) {
            if (point1.isSelected() || point2.isSelected() || point3.isSelected() || point4.isSelected()
                  || point5.isSelected()) {

           
               int num = 0;
               if (point1.isSelected()) {
                  num = 1;
               } else if (point2.isSelected()) {
                  num = 2;
               } else if (point3.isSelected()) {
                  num = 3;
               } else if (point4.isSelected()) {
                  num = 4;
               } else if (point5.isSelected()) {
                  num = 5;
               }

               for (int i = 0; i < menuButton.length; i++) {
                  if (menuButton[i].isSelected()) {
                     // 작성한 후기를 리스트에 추가
                  //  new MovieDAO().inputReview(menuButton[i].getText(), reviewName.getText(), review.getText(), num);
                  }
               } 

               JOptionPane.showMessageDialog(null, "리뷰 작성을 완료하였습니다.");
               FrameBase.getInstance(new DeliveryRev());

            } else {
               JOptionPane.showMessageDialog(null, "평점을 입력해주세요.");
            }
         }
      });*/

		//이름입력
		JLabel nl1 = new JLabel();
		nl1.setBorder(new TitledBorder(new LineBorder(Color.LIGHT_GRAY),
		        "이름", TitledBorder.LEADING, 
		        TitledBorder.TOP,
		        new Font (" monospaced", Font.BOLD, 17), 
		        new Color(255, 153, 051)));
		nl1.setSize(564,80);
		nl1.setLocation(10, 460);
		TextField tff = new TextField(50);
		tff.setBounds(30, 490, 200, 30);
		tff.setFont(new Font(" monospaced", Font.BOLD, 16));
		nl1.setFont(new Font(" monospaced", Font.BOLD, 14));
		
		add(tff);
		add(nl1);
		
		//평가
		JLabel n2 = new JLabel();
		n2.setBorder(new TitledBorder(new LineBorder(Color.LIGHT_GRAY),
		        "리뷰를 남겨주세요", TitledBorder.LEADING, 
		        TitledBorder.TOP,
		        new Font (" monospaced", Font.BOLD, 17), 
		        Color.DARK_GRAY));
		TextField rev = new TextField(50);
		n2.setSize(564, 150);
		n2.setLocation(10, 540);
		n2.setFont(new Font(" monospaced", Font.BOLD, 16));
		rev.setBounds(30,580,520,100);
		rev.setFont(new Font(" monospaced", Font.BOLD,16));
		add(rev);
		add(n2);
		
		
		ImageIcon oo = new ImageIcon("리뷰작성.png");
		
		JButton bt = new JButton("리뷰작성");
		 
		bt.setBounds(470, 700, 100, 50);
		bt.setBackground(new Color(255,255,255));
		add(bt);
		bt.setEnabled(false);
		bt.setFont(new Font(" monospaced", Font.BOLD, 14));
		
		rev.addTextListener(new TextListener() {
			
			@Override
			public void textValueChanged(TextEvent e) {
				if(rev.getText().equals("")) {
					bt.setEnabled(false);
					
				}
				else {
					bt.setEnabled(true);
				}
				
			}
		});
		bt.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(rev.getText()=="") {
					JOptionPane.showMessageDialog(null, "리뷰를 작성해주세요");
				}
				else
				JOptionPane.showMessageDialog(null, tff.getText()+"님"+"\n"+"리뷰작성 감사합니다 ");
				//System.exit(0);
				
			}
			
		});
		

   }// 생성자

}