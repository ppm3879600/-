package main;

import frame.DeliveryC;
import frame.FrameBase;

public class Main {
	
	public static void main(String[] args) {
		
	FrameBase.getInstance(new DeliveryC());
	}
	
	
		
}
